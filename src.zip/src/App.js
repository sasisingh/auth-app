import React from 'react';
import './App.css';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import SignUp from './pages/SignUp';
import Login from './pages/Login';
import DashBoard from './pages/DashBoard';
import Error from './pages/Error';

const ProtectedRoute = ({ children }) => {
	const token = localStorage.getItem("Token")
	return token == null ? <Navigate to="/login" /> : children
}

const AuthRoute = ({ children }) => {
	const token = localStorage.getItem("Token")
	return token != null ? <Navigate to="/dashboard" /> : children
}
function App() {

	return (
		<div className="App">
			<BrowserRouter>
				<Routes>
					<Route path="/" element={
						<AuthRoute>
							<SignUp />
						</AuthRoute>
					}></Route>
					<Route path='/login' element={
						<AuthRoute>
							<Login />
						</AuthRoute>

					}></Route>
					<Route path="/dashboard"
						element={
							<ProtectedRoute>
								<DashBoard />
							</ProtectedRoute>

						}></Route>
						<Route path='/*' element={<Error/>}></Route>
				</Routes>
			</BrowserRouter>
		</div>
	);
}

export default App;
