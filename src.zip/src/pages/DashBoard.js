import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import 'mdb-react-ui-kit/dist/css/mdb.min.css';
import {
	MDBBtn,
	MDBContainer,
	MDBCard,
	MDBCardBody,
	MDBRow,
	MDBCol,
	MDBInput,
	MDBTextArea
} from 'mdb-react-ui-kit';
import Header from './Header';
import Footer from './Footer';
import axios from 'axios';

const DashBoard = () => {
	const [name, setName] = useState("")
	const [email, setEmail] = useState("")
	const [password, setPassword] = useState("")
	const [confirmPassword, setConfirmPassword] = useState("")
	const [twitter, setTwitter] = useState("")
	const [facebook, setFacebook] = useState("")
	const [instagram, setInstagram] = useState("")
	const [linkedIn, setLinkedIn] = useState("")

	const submitdata = ()=>{
			axios({
				method: 'put',
				url: 'http://api.mern.co.in/api/v1/signup',
				data: {
					"name": name,
					"email": email,
					"password": password,
					"confirm_password": confirmPassword
				}
			}).then((resp) => {
				console.log(resp)
			}).catch((err) => {
				console.log("Error", err)
			})
	}
	return (
		<div>
			<MDBContainer className='my-5'>
				<Header />
				<MDBCard>
					<h2 className="fw-bold my-4">User Profile</h2>
					<MDBRow className='g-0 d-flex align-items-center'>

						<MDBCol md='4'>
							<div class="card" style={{ "width": "18rem", margin: " 0px 50px" }}>
								<img src="https://mdbcdn.b-cdn.net/img/new/standard/city/062.webp" class="card-img-top" alt="Chicago Skyscrapers" style={{ padding: "0px 20px" }} />
								<div class="card-body">
									<h5 class="card-title">Shashi Singh</h5>
									<p class="card-text">Project Manager</p>
									<hr />
									<p>Description</p>
									<p>React Bootstrap textarea is an input dedicated for a large volume of texta large volume of texta large volume of text.
										It may be used in a variety of components like fo .</p>
								</div>
							</div>
						</MDBCol>

						<MDBCol md='8'>
							<MDBCardBody className='p-5 text-center'>
								<h2 className="fw-bold mb-4">Account Details</h2>
								<MDBRow>
									<MDBCol col='6' >
										<MDBInput wrapperClass='mb-4' label='Name' id='form1' type='text' onChange={(e) => { setName(e.target.value) }} />
									</MDBCol>
									<MDBCol col='6'>
										<MDBInput wrapperClass='mb-4' label='Email' id='form1' type='email' onChange={(e) => { setEmail(e.target.value) }} />
									</MDBCol>
								</MDBRow>
								<MDBRow>
									<MDBCol col='6' >
										<MDBInput wrapperClass='mb-4' label='Password' id='form1' type='password' onChange={(e) => { setPassword(e.target.value) }} />
									</MDBCol>
									<MDBCol col='6'>
										<MDBInput wrapperClass='mb-4' label='Confirm Password' id='form1' type='password' onChange={(e) => { setConfirmPassword(e.target.value) }} />
									</MDBCol>
								</MDBRow>
								<MDBRow>
									<MDBCol col='6' >
										<MDBInput wrapperClass='mb-4' label='Twitter' id='form1' type='text' onChange={(e) => { setTwitter(e.target.value) }} />
									</MDBCol>
									<MDBCol col='6'>
										<MDBInput wrapperClass='mb-4' label='Facebook' id='form1' type='text' onChange={(e) => { setFacebook(e.target.value) }} />
									</MDBCol>
								</MDBRow>
								<MDBRow>
									<MDBCol col='6' >
										<MDBInput wrapperClass='mb-4' label='Instagram' id='form1' type='text' onChange={(e) => { setInstagram(e.target.value) }} />
									</MDBCol>
									<MDBCol col='6'>
										<MDBInput wrapperClass='mb-4' label='LinkedIn' id='form1' type='text' onChange={(e) => { setLinkedIn(e.target.value) }} />
									</MDBCol>
								</MDBRow>
								<MDBTextArea wrapperClass='mb-4' label='Description' id='form1' type='text' />
								<MDBBtn className='w-100 ' size='md' onClick={submitdata}>sign up</MDBBtn>
							</MDBCardBody>
						</MDBCol>
					</MDBRow>
					<Footer />
				</MDBCard>

			</MDBContainer>

		</div>

	)
}

export default DashBoard;
